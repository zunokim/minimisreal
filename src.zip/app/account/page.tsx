// src/app/account/page.tsx
import AccountClient from './AccountClient'

export const dynamic = 'force-dynamic'

export default function AccountPage() {
  return <AccountClient />
}
