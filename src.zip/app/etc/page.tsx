// ✅ src/app/etc/page.tsx
export default function EtcPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold">⚙️ ETC 페이지입니다.</h2>
    </div>
  )
}
