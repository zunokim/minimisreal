// src/app/data/rone-vacancy/page.tsx
import RoneVacancyClient from './RoneVacancyClient'
export const dynamic = 'force-dynamic'

export default function Page() {
  return <RoneVacancyClient />
}
