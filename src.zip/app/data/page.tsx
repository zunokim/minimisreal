// src/app/data/page.tsx
import DataClient from './DataClient'

export const dynamic = 'force-dynamic'

export default function DataPage() {
  return <DataClient />
}
