// src/app/data/rone-office/page.tsx
import RoneOfficeClient from './RoneOfficeClient'

export const dynamic = 'force-dynamic'

export default function RoneOfficePage() {
  return <RoneOfficeClient />
}
